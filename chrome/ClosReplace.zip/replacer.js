findAndReplaceDOMText(document.body, {
  find: /Clos/,
  wrap: 'b',
  preset: 'prose'
});
